<html>
<head>
<title>Pizza Express|Доставка піци Львів|Замовити піцу Львів|Піца Львів</title>
<meta name=viewport content="width=device-width, initial-scale=0.85">
<meta name="description" content="Express Pizza Львів - це ресторан для швидкої доставки піци у Львові,замовлення смачної піци у Львові,заказ піци у Львові">
<meta name="keywords" content="Express Pizza Львів,Доставка піци Львів,Замовити піцу Львів,Експресс піца Львів,заказати піцу Львів,Піца Львів">
<link rel="shortcut icon" size="50px" href="favicon.png" type="image/x-icon">
<link rel="stylesheet" href="css/style.css" type="text/css">
</head>