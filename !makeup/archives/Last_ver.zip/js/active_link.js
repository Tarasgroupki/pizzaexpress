﻿var $passive_link = $('.short_cart1');
var $div = $('.one');

$passive_link.on('click',function(){
	$div.toggleClass('underline_header');
	});