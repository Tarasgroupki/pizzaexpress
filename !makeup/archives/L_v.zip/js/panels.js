﻿var $btn = $('.short_cart');
var $panel = $('.panel');

$btn.on('click',function(){
	$panel.toggleClass('js-panel-open');
	});